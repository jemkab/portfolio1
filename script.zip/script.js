$(function() {

    var n=0
    
    function slide(){
        if(n<2){
            n++;
        }else{
            n=0;
        }
        
        $(".slide ul li").fadeOut();
        $(".slide ul li").eq(n).fadeIn();
    }
   
    setInterval(slide, 3000)

    $("nav>ul>li").mouseenter(function(){
        $(this).find('.sub').stop().fadeIn();
    })
    $("nav>ul>li").mouseleave(function(){
        $(".sub").stop().fadeOut();
    })
})